<?php

class crumbs_UnserializeException extends Exception {

}