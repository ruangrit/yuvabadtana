
## Notes about the Container architecture.

If you look at this folder and say it is all crazy: You are right!

There are reasons for this design. But, it could all be done in a different and
better way.

Some issues:
- overall too complex and too abstract
- too much magic going on, no type hints

This stuff works now and so we are not going to change it that soon.