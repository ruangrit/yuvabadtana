This is simple module to integrate the CKEditor MediaEmbed plugin with the 
Wysiwyg module.


INSTALLATION

1) Download and install the Wysiwyg MediaEmbed module as usual.
2) Download the Media Embed plugin from 
   http://www.fluidbyte.net/index.php?view=embed-youtube-vimeo-etc-into-ckeditor
3) Unzip the plugin in the 'plugin' folder. The main Javascript file of 
   the module should be in 'wysiwyg_mediaembed/plugin/mediaembed/plugin.js'
4) Enable the plugin in the Wysiwyg profile configuration page.

This module was largely inpired by the discussion at 
http://groups.drupal.org/node/55688#comment-634648

