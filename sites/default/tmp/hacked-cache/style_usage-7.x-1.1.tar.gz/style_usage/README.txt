
Provides advanced management of image styles.

This module only need in development stage of a project,
you should turn off on production site.

Implemented usage list:

- What views, what display and what field.
- Which entities, which bundle, which field, which display mode.
- Which file type, which view mode, which display name. (Requires File
  entity module.
- Easier effect edit.

-- Licence of images --
This module contains two high quality image for testing.
The images in module are free for use, see:
http://www.stockfreeimages.com/473249/A-fighter-plane.html
http://www.stockfreeimages.com/1673013/F15-Fighter.html

-- Usage --

Just enable the module, then go admin/config/media/image-styles/usage.
More information and issue queue:

http://drupal.org/sandbox/szantog/1305076
http://drupal.org/project/issues/1305076
